const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const mongoose = require('mongoose');
//specify where to find the schema
const Patient = require('./models/patient')
//connect and display the status
mongoose.connect('mongodb://localhost:27017/IT6203', {
     useNewUrlParser: true,  useUnifiedTopology: true })
    .then(() => { console.log("connected"); })
    .catch(() => { console.log("error connecting"); });
//specify which domains can make requests and which methods are allowed
app.use((req, res, next) => {
    console.log('This line is always called');
    res.setHeader('Access-Control-Allow-Origin', '*'); //can connect from any host
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, OPTIONS, DELETE'); //allowable methods
    res.setHeader('Access-Control-Allow-Headers', 'Origin, Content-Type, Accept');
    next();
})
//parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({extended: false}))

//parse application/json
app.use(bodyParser.json())

//in the app.get() method below we add a path for the students API 
//by adding /students, we tell the server that this method will be called every time http://localhost:8000/students is requested. 
app.get('/patient', (req, res, next) => {
    //we will add an array named students to pretend that we received this data from the database
   /*  const patients = [ 
    { "id" : "1", "firstName" : "John" , "lastName" : "Dow"  }, 
    { "id" : "2", "firstName" : "Ann" , "lastName" : "Smith" }, 
    { "id" : "3", "firstName" : "Joan" , "lastName" : "Doe" }];
    //send the array as the response 
    res.json(patients); */

// call mongoose method find (MongoDB db.Patient.find())
Patient.find()
//if data is returned, send data as a response
.then(data => res.status(200).json(data))
//if error, send internal server error
.catch(err =>{
    console.log('Error: ${err}');
    res.status(500).json(err);
});

});

//serve incomming post request to / patients
app.post('/patient', (req, res, next) =>{
/*     const patient = req.body;
    console.log(patient.firstName +
        " " + patient.lastName +
        " " + patient.dob +
        " " + patient.phone +
        " " + patient.patientType +
        " " + patient.gender +
        " " + patient.reasonOfVisit+
        " " + patient.street+
        " " + patient.cityName+
        " " + patient.state+
        " " + patient.zip
        );
    //sent an acknowledgement back to caller
    res.status(201).json('Post successfull');
    
}); */

//Create a new patient variable and save request's fields
const patient = new Patient({
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    dob: req.body.dob,
    phone: req.body.phone,
    patientType: req.body.patientType,
    gender: req.body.gender,
    reasonOfVisit: req.body.reasonOfVisit,
  /*   street: req.body.street,
    cityName: req.body.cityName,
    state: req.body.state,
    zip: req.body.zip */

});

//send the document to the database
patient.save()
//incase of success
.then(() =>{console.log('Success');})
//if error
.catch(err =>{ console.log('Error:' +err);});
});

//:id is a dynamic parameter that will be extracted from the URL
app.delete("/patient/:id", (req, res, next) => {
    Patient.deleteOne({ _id: req.params.id }).then(result => {
        console.log(result);
        res.status(200).json("Deleted!");
    });




//serve incoming put requests to /patients 
app.put('/patient/:id', (req, res, next) => { 
    console.log("id: " + req.params.id) 
    // check that the parameter id is valid 
    if (mongoose.Types.ObjectId.isValid(req.params.id)) { 
        //find a document and set new first and last names 
        Patient.findOneAndUpdate( 
            {_id: req.params.id}, 
            {$set:{ 
                firstName: req.body.firstName,
                lastName: req.body.lastName,
                dob: req.body.dob,
                phone: req.body.phone,
                patientType: req.body.patientType,
                gender: req.body.gender,
                reasonOfVisit: req.body.reasonOfVisit,
                /* street: req.body.street,
                cityName: req.body.cityName,
                state: req.body.state,
                zip: req.body.zip */

                
            }}, 
            {new:true} 
        ) 
        .then((patient) => { 
            if (patient) { //what was updated 
                console.log(patient); 
            } else { 
                console.log("no data exist for this id"); 
            } 
        }) 
        .catch((err) => { 
            console.log(err); 
        }); 
    } else { 
        console.log("please provide correct id"); 
    } 
});
});


//to use this middleware in other parts of the application
module.exports=app;
                    
