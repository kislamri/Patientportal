import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router, ParamMap } from '@angular/router';
import { PatientService } from '../patient.service';

@Component({
  selector: 'app-new-patient-form',
  templateUrl: './new-patient-form.component.html',
  styleUrls: ['./new-patient-form.component.css']
})
export class NewPatientFormComponent implements OnInit {

  @Input() firstName: string = "";
  @Input() lastName: string = "";
  @Input() dob: Date ;
  @Input() phone: string;
  @Input() patientType: string = "";
  @Input() gender: string = "";
  @Input() reasonOfVisit: string = ""
 /*  @Input() street: string = "";
  @Input() cityName: string = "";
  @Input() state: string = "";
  @Input() zip: string = ""; */


  
  public mode = 'Add'; //default mode
 
  private id: any; //patient ID
  private patient:any;

//initialize the call using PatientprotalService
  constructor(private router: Router, public route: ActivatedRoute,
    private _myService: PatientService, public fb:FormBuilder) {
     /*  this. cityName = ""; */
     }
     bindedTwoWays = '';

  ngOnInit() {
    this.route.paramMap.subscribe((paramMap: ParamMap) =>{
      if (paramMap.has('_id'))
      { this.mode = 'Edit'; /*request had a parameter _id*/
        this.id = paramMap.get('_id');
      }
      else{
        this.mode = 'Add';
        this.id = null;
      }
    });
  }

/*   getcityNameByZip(inputValue: string){
    console.warn("Key up: Zip code field "+ inputValue);
  
  let map = new Map<string, string>();
      map.set("30068", "Marietta"); 
      map.set("30067", "Marietta");
      map.set("30144", "Kennesaw");
      map.set("30152", "Kennesaw");
      map.set("30047", "Lilburn");
      map.set("30078", "Atlanta");

      console.log("City name: " + map.get(inputValue));
      this.changeCityNameField(map.get(inputValue) + "")
  }
  private changeCityNameField(city: string): void {
    this.cityName= city;
  } */

  onSubmit(){
    console.log("You submitted "  + this. firstName +
                " " + this.lastName +
                " " + this.dob +
                " " + this.phone+
                " " + this.patientType+
                " " + this.gender+
                " " + this.reasonOfVisit
               /*  " " + this.street+
                " " + this.cityName+
                " " + this.state+
                " " + this.zip */
                );
    if( this.mode =='Add')            
    this._myService.addPatient(
      this.firstName,
      this.lastName, 
      this.dob, 
      this.phone, 
      this.patientType, 
      this.gender, 
      this.reasonOfVisit
   /*    this.street, 
      this.cityName, 
      this.state, 
      this.zip  */
      );
    
     if( this.mode =='Edit')            
      this._myService.updatePatient(
        this.id,
        this.firstName,
        this.lastName, 
        this.dob, 
        this.phone, 
        this.patientType, 
        this.gender, 
        this.reasonOfVisit
       /*  this.street, 
        this.cityName, 
        this.state, 
        this.zip  */
        );
        this.router.navigate(['/listPatients']) ;

  }

}
