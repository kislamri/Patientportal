import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes} from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';

import { AppointmentComponent } from './appointment/appointment.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { SicknessComponent } from './sickness/sickness.component';
import { HttpClientModule } from '@angular/common/http';
import { PatientService } from './patient.service';
import { NewPatientFormComponent } from './new-patient-form/new-patient-form.component'
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { NavigationMenuComponent } from './navigation-menu/navigation-menu.component';
import { ListPatientsComponent } from './list-patients/list-patients.component';
import { NotFoundComponent } from './not-found/not-found.component';


const appRoutes : Routes = [
  {path : '', redirectTo: 'patient' , pathMatch: 'full'},
  {path:'home', component: HomeComponent},
  {path: 'new-patient-form', component:NewPatientFormComponent},
  /* {path: 'appointment', component:AppointmentComponent},
  {path: 'doctors', component:DoctorsComponent},
  {path: 'sickness', component:SicknessComponent}, */

  {path: '',  //default component to display
  component: ListPatientsComponent
}, {
  path: 'addPatient',  //when patients added 
  component: NewPatientFormComponent
}, 
{
    path: 'editPatient/:_id', //when patients edited 
    component: NewPatientFormComponent 
},
     
{
  path: 'listPatients',  //when patients listed
  component: ListPatientsComponent
}, {
  path: '**',  //when path cannot be found
  component: NotFoundComponent
}

  ];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AppointmentComponent,
    DoctorsComponent,
    SicknessComponent,
    NewPatientFormComponent,
    NavigationMenuComponent,
    NotFoundComponent,
    ListPatientsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatFormFieldModule,
    MatInputModule,
    BrowserAnimationsModule,
    FormsModule,
    MatButtonModule,
    MatMenuModule,
    MatIconModule,
    RouterModule.forRoot(appRoutes),
    
  ],
  providers: [PatientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
