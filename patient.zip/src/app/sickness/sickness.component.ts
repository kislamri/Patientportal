import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sickness',
  templateUrl: './sickness.component.html',
  styleUrls: ['./sickness.component.css']
})
export class SicknessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
